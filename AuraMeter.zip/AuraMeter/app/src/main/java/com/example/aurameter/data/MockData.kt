package com.example.aurameter.data

import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf

object MockRepository {

    // Current User
    val currentUser = mutableStateOf(
        UserProfile(
            id = "user_me",
            name = "Kaelen Voss",
            username = "@kaelen_aura",
            avatarUrl = "https://i.pravatar.cc/300?img=12",
            auraPoints = 48590L,
            globalRank = 42,
            levelTitle = "Aura Overlord IV",
            auraMultiplier = 2.5f,
            streakDays = 18,
            clanName = "Aetherium Syndicate"
        )
    )

    // Daily Challenges
    val dailyChallenges = mutableStateListOf(
        DailyChallenge(
            id = "c1",
            title = "Meditar en Zona Radiante",
            description = "Escanea el mapa y permanece 5 min cerca de un Hotspot de Aura.",
            rewardAura = 1200,
            rewardMultiplier = "x1.5",
            isCompleted = false,
            category = "Exploración",
            iconName = "Map"
        ),
        DailyChallenge(
            id = "c2",
            title = "Duelo de Aura Directo",
            description = "Gana 1 Batalla de Aura en el Feed de Shorts.",
            rewardAura = 2500,
            rewardMultiplier = "x2.0",
            isCompleted = true,
            category = "Batallas",
            iconName = "Bolt"
        ),
        DailyChallenge(
            id = "c3",
            title = "Ofrenda de Clan",
            description = "Regala Aura a un compañero de clan o contacto.",
            rewardAura = 800,
            rewardMultiplier = "+500 Aura Bonus",
            isCompleted = false,
            category = "Social",
            iconName = "CardGiftcard"
        ),
        DailyChallenge(
            id = "c4",
            title = "Racha Legendaria",
            description = "Publica tu racha actual en el Feed Social con tag #AuraPower.",
            rewardAura = 1800,
            rewardMultiplier = "x3.0 Multiplier (1h)",
            isCompleted = false,
            category = "Comunidad",
            iconName = "LocalFireDepartment"
        )
    )

    // Feed Posts
    val feedPosts = mutableStateListOf(
        Post(
            id = "p1",
            authorName = "Valeria Sparks",
            authorUsername = "@valeria_neon",
            authorAvatar = "https://i.pravatar.cc/300?img=5",
            authorAura = 124500L,
            content = "¡Racha de 30 días alcanzada! 🔥 Mi Aura aumentó +15,000 en el Hotspot de Madrid. ¿Quién se atreve a un duelo esta noche?",
            auraStreakDays = 30,
            auraEarned = 15000,
            likesCount = 342,
            commentsCount = 28,
            repostsCount = 14,
            timeAgo = "Hace 12 min",
            isLiked = true
        ),
        Post(
            id = "p2",
            authorName = "Aetherium Syndicate",
            authorUsername = "@aether_clan",
            authorAvatar = "https://i.pravatar.cc/300?img=60",
            authorAura = 9804000L,
            content = "¡Invasión de Clan exitosa en la Zona Alfa! Dominamos el ranking semanal con más de 9M de Aura acumulada. 👑 #AuraOverlords",
            auraStreakDays = 45,
            auraEarned = 120000,
            likesCount = 1280,
            commentsCount = 142,
            repostsCount = 89,
            timeAgo = "Hace 45 min",
            isLiked = false
        ),
        Post(
            id = "p3",
            authorName = "Dante Zero",
            authorUsername = "@dante_god",
            authorAvatar = "https://i.pravatar.cc/300?img=68",
            authorAura = 312000L,
            content = "¡Giré la Ruleta Diaria y conseguí el Multiplicador x3! Mi barra de Aura explotó. ⚡🔥⚡",
            auraStreakDays = 12,
            auraEarned = 8500,
            likesCount = 520,
            commentsCount = 41,
            repostsCount = 19,
            timeAgo = "Hace 2 horas",
            isLiked = false
        )
    )

    // Shorts Videos
    val shortsVideos = mutableStateListOf(
        ShortVideo(
            id = "s1",
            creatorName = "Sora Cyber",
            creatorAvatar = "https://i.pravatar.cc/300?img=32",
            creatorRank = 3,
            battleTitle = "DUELO ULTRA: Sora (310k) VS Ryker (290k) ⚡",
            auraStakes = 50000L,
            gradientColorsHex = listOf(0xFF2E0854, 0xFF8B00FF, 0xFF00F0FF),
            likesCount = 14200,
            commentsCount = 890,
            sharesCount = 320,
            isFollowing = true
        ),
        ShortVideo(
            id = "s2",
            creatorName = "Aura Queen Nova",
            creatorAvatar = "https://i.pravatar.cc/300?img=47",
            creatorRank = 1,
            battleTitle = "¡Escaneando la Zona VIP de Tokio! +25,000 Aura cosechada 🔮",
            auraStakes = 100000L,
            gradientColorsHex = listOf(0xFF4A0033, 0xFFFF007A, 0xFFFFD700),
            likesCount = 38900,
            commentsCount = 2100,
            sharesCount = 1150,
            isFollowing = false
        ),
        ShortVideo(
            id = "s3",
            creatorName = "Ronin X",
            creatorAvatar = "https://i.pravatar.cc/300?img=11",
            creatorRank = 8,
            battleTitle = "Batalla Relámpago de Clan: ¡Defendiendo la Corona! 🛡️⚡",
            auraStakes = 25000L,
            gradientColorsHex = listOf(0xFF042940, 0xFF00FF88, 0xFF00F0FF),
            likesCount = 8900,
            commentsCount = 412,
            sharesCount = 180,
            isFollowing = true
        )
    )

    // Contacts for Chat
    val contacts = mutableStateListOf(
        Contact(
            id = "c_nova",
            name = "Nova Starling",
            username = "@nova_prime",
            avatarUrl = "https://i.pravatar.cc/300?img=47",
            auraPoints = 512000L,
            rank = 1,
            activeMission = "Dominación de Zona Neón (80%)",
            isOnline = true,
            lastMessage = "¡Ese regalo de Aura estuvo genial! Gracias brother 🔥",
            lastMessageTime = "10:42 AM"
        ),
        Contact(
            id = "c_ryker",
            name = "Ryker Vance",
            username = "@ryker_v",
            avatarUrl = "https://i.pravatar.cc/300?img=33",
            auraPoints = 289000L,
            rank = 5,
            activeMission = "Cacería de Sombras (45%)",
            isOnline = true,
            lastMessage = "¿Hacemos grupo para el evento de Clan?",
            lastMessageTime = "Ayer"
        ),
        Contact(
            id = "c_elena",
            name = "Elena Shadow",
            username = "@elena_dark",
            avatarUrl = "https://i.pravatar.cc/300?img=9",
            auraPoints = 195400L,
            rank = 12,
            activeMission = "Racha de Meditación (100%)",
            isOnline = false,
            lastMessage = "Nos vemos en el mapa esta tarde.",
            lastMessageTime = "Mar"
        )
    )

    // Chat History
    val chatMessages = mutableStateListOf(
        ChatMessage("m1", "c_nova", "Nova Starling", "¡Hey Kaelen! Vi que subiste al puesto #42 global, felicitaciones 🔥", "10:30 AM", false),
        ChatMessage("m2", "user_me", "Kaelen Voss", "¡Gracias Nova! Voy por el Top 20 esta semana.", "10:32 AM", true),
        ChatMessage("m3", "c_nova", "Nova Starling", "Te envié una invitación para la misión de Clan.", "10:35 AM", false),
        ChatMessage("m4", "system", "Aura System", "⚡ Kaelen te regaló +1,000 AURA ⚡", "10:40 AM", false, auraGifted = 1000, isSystemNotice = true),
        ChatMessage("m5", "c_nova", "Nova Starling", "¡Ese regalo de Aura estuvo genial! Gracias brother 🔥", "10:42 AM", false)
    )

    // Leaderboard Users
    val weeklyLeaderboard = mutableStateListOf(
        LeaderboardUser(1, "l1", "Nova Starling", "@nova_prime", "https://i.pravatar.cc/300?img=47", 512000L, +85000L, "DIOS DEL AURA ⚡", isLeader = true, rankChange = 0),
        LeaderboardUser(2, "l2", "Zephyr Blade", "@zephyr_x", "https://i.pravatar.cc/300?img=68", 420500L, +62000L, "Titán Supremo", rankChange = +1),
        LeaderboardUser(3, "l3", "Sora Cyber", "@sora_c", "https://i.pravatar.cc/300?img=32", 389000L, +54000L, "Señor Elemental", rankChange = -1),
        LeaderboardUser(4, "l4", "Valkyrie Neón", "@valk_neon", "https://i.pravatar.cc/300?img=49", 298000L, +41000L, "Sombra Estelar", rankChange = +3),
        LeaderboardUser(5, "l5", "Ryker Vance", "@ryker_v", "https://i.pravatar.cc/300?img=33", 289000L, +38000L, "Guardián Carmesí", rankChange = -1),
        LeaderboardUser(6, "l6", "Dante Zero", "@dante_g", "https://i.pravatar.cc/300?img=12", 245000L, +31000L, "Cazador Neón", rankChange = 0),
        LeaderboardUser(7, "l7", "Aria Phoenix", "@aria_phx", "https://i.pravatar.cc/300?img=23", 210000L, +29000L, "Llama Divina", rankChange = +2),
        LeaderboardUser(8, "l8", "Ronin X", "@ronin_x", "https://i.pravatar.cc/300?img=11", 198000L, +22000L, "Maestro Cyber", rankChange = -2),
        LeaderboardUser(42, "user_me", "Kaelen Voss (Tú)", "@kaelen_aura", "https://i.pravatar.cc/300?img=12", 48590L, +12400L, "Aura Overlord IV", rankChange = +5)
    )

    // Clans
    val clans = mutableStateListOf(
        Clan(
            id = "clan_1",
            name = "Aetherium Syndicate",
            tag = "AETH",
            emblemIcon = "Shield",
            totalAura = 12850000L,
            memberCount = 48,
            maxMembers = 50,
            rank = 1,
            description = "El clan dominante de la red. Solo guerreros con Aura > 30k.",
            leaderName = "Nova Starling",
            isUserMember = true
        ),
        Clan(
            id = "clan_2",
            name = "Neon Dynasty",
            tag = "NEON",
            emblemIcon = "Bolt",
            totalAura = 9420000L,
            memberCount = 50,
            maxMembers = 50,
            rank = 2,
            description = "Unión cyber de élite enfocada en conquista territorial en el Mapa.",
            leaderName = "Zephyr Blade",
            isUserMember = false
        ),
        Clan(
            id = "clan_3",
            name = "Shadow Overlords",
            tag = "SHDW",
            emblemIcon = "Visibility",
            totalAura = 7180000L,
            memberCount = 42,
            maxMembers = 50,
            rank = 3,
            description = "Gremio enfocado en duelos sigilosos y multiplicadores nocturnos.",
            leaderName = "Elena Shadow",
            isUserMember = false
        )
    )

    // Clan Missions
    val clanMissions = listOf(
        ClanMission("cm1", "Conquista de 10 Hotspots en el Mapa", 8, 10, 250000L, 2),
        ClanMission("cm2", "Acumular 1,000,000 Aura Colectiva esta semana", 780000, 1000000, 500000L, 4),
        ClanMission("cm3", "Ganar 50 Duelos de Aura Sociales", 34, 50, 150000L, 5)
    )

    // Clan Members
    val clanMembers = listOf(
        ClanMember("m1", "Nova Starling", "Líder Supremo", 2100000L, 1, true),
        ClanMember("m2", "Kaelen Voss (Tú)", "Oficial Neón", 48590L, 12, true),
        ClanMember("m3", "Ryker Vance", "Guardián", 1250000L, 3, true),
        ClanMember("m4", "Elena Shadow", "Reclutadora", 890000L, 5, false)
    )

    // Roulette Prizes
    val roulettePrizes = listOf(
        RoulettePrize("r1", "+5,000 AURA", "Bonus Masivo", 5000, 1.0f, false, 0xFF00FF88),
        RoulettePrize("r2", "MULTIPLICADOR x2", "2 Horas Activo", 0, 2.0f, false, 0xFF00F0FF),
        RoulettePrize("r3", "-2,000 AURA", "¡PELIGRO! RIESGO", -2000, 1.0f, true, 0xFFFF2A4B),
        RoulettePrize("r4", "+10,000 AURA", "¡JACKPOT NEÓN!", 10000, 1.0f, false, 0xFFFFD700),
        RoulettePrize("r5", "MULTIPLICADOR x3", "1 Hora Legendario", 0, 3.0f, false, 0xFFB026FF),
        RoulettePrize("r6", "-500 AURA", "Penalización Trampa", -500, 1.0f, true, 0xFFFF007A)
    )

    // Heat Zones for Pokémon GO style Map
    val heatZones = listOf(
        HeatZone("hz1", "Gran Vía Hotspot", 0.95f, 142, 0.45f, 0.38f, 140f),
        HeatZone("hz2", "Plaza Central Cyber", 0.80f, 98, 0.72f, 0.55f, 110f),
        HeatZone("hz3", "Distrito de Innovación", 0.65f, 54, 0.25f, 0.68f, 85f),
        HeatZone("hz4", "Zona Neón Norte", 0.50f, 32, 0.60f, 0.20f, 70f)
    )

    // Radar Users nearby
    val radarUsers = mutableStateListOf(
        RadarUser("ru1", "Valkyrie Neón", 298000L, 4, 45, 0.48f, 0.42f, "Sombra Estelar"),
        RadarUser("ru2", "Dante Zero", 245000L, 6, 120, 0.68f, 0.52f, "Cazador Neón"),
        RadarUser("ru3", "Ronin X", 198000L, 8, 230, 0.30f, 0.62f, "Maestro Cyber"),
        RadarUser("ru4", "Aura Shadow", 152000L, 15, 380, 0.78f, 0.28f, "Llama Carmesí")
    )

    // State helper actions
    fun completeChallenge(challengeId: String) {
        val index = dailyChallenges.indexOfFirst { it.id == challengeId }
        if (index != -1 && !dailyChallenges[index].isCompleted) {
            val challenge = dailyChallenges[index]
            dailyChallenges[index] = challenge.copy(isCompleted = true)
            currentUser.value = currentUser.value.copy(
                auraPoints = currentUser.value.auraPoints + challenge.rewardAura
            )
        }
    }

    fun giftAura(contactId: String, amount: Int) {
        if (currentUser.value.auraPoints >= amount) {
            currentUser.value = currentUser.value.copy(
                auraPoints = currentUser.value.auraPoints - amount
            )
            chatMessages.add(
                ChatMessage(
                    id = "msg_${System.currentTimeMillis()}",
                    senderId = "system",
                    senderName = "Aura System",
                    text = "⚡ Enviaste un regalo de +$amount AURA ⚡",
                    timestamp = "Ahora",
                    isFromMe = true,
                    auraGifted = amount,
                    isSystemNotice = true
                )
            )
        }
    }
}
