package com.example.aurameter.ui.navigation

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.aurameter.ui.screens.auth.AuthScreen
import com.example.aurameter.ui.screens.clans.ClanSystemScreen
import com.example.aurameter.ui.screens.home.HomeScreen
import com.example.aurameter.ui.screens.leaderboard.WeeklyLeaderboardScreen
import com.example.aurameter.ui.screens.map.AuraMapScreen
import com.example.aurameter.ui.screens.roulette.DailyRouletteScreen
import com.example.aurameter.ui.screens.settings.SettingsScreen
import com.example.aurameter.ui.screens.social.DirectChatDetailScreen
import com.example.aurameter.ui.screens.social.SocialScreen
import com.example.aurameter.ui.theme.AuraDarkBackground

@Composable
fun AuraNavGraph() {
    val navController = rememberNavController()
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route

    // Show Bottom Bar on main screens and sub-screens except Auth
    val showBottomBar = currentRoute != Screen.Auth.route

    Scaffold(
        bottomBar = {
            if (showBottomBar) {
                AuraBottomBar(navController = navController)
            }
        },
        containerColor = AuraDarkBackground
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            NavHost(
                navController = navController,
                startDestination = Screen.Home.route
            ) {
                // Main 3 BottomBar Screens
                composable(Screen.Home.route) {
                    HomeScreen(navController = navController)
                }
                composable(Screen.Social.route) {
                    SocialScreen(navController = navController)
                }
                composable(Screen.Settings.route) {
                    SettingsScreen(navController = navController)
                }

                // Ecosystem Sub-screens
                composable(Screen.AuraMap.route) {
                    AuraMapScreen(navController = navController)
                }
                composable(Screen.DailyRoulette.route) {
                    DailyRouletteScreen(navController = navController)
                }
                composable(Screen.ClanSystem.route) {
                    ClanSystemScreen(navController = navController)
                }
                composable(Screen.Leaderboard.route) {
                    WeeklyLeaderboardScreen(navController = navController)
                }
                composable(
                    route = Screen.DirectChatDetail.route,
                    arguments = listOf(navArgument("contactId") { type = NavType.StringType })
                ) { backStackEntry ->
                    val contactId = backStackEntry.arguments?.getString("contactId") ?: "c_nova"
                    DirectChatDetailScreen(contactId = contactId, navController = navController)
                }
                composable(Screen.Auth.route) {
                    AuthScreen(navController = navController)
                }
            }
        }
    }
}
