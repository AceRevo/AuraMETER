package com.example.aurameter.ui.screens.roulette

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Casino
import androidx.compose.material.icons.filled.ChangeCircle
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.aurameter.data.MockRepository
import com.example.aurameter.data.RoulettePrize
import com.example.aurameter.ui.components.AuraGlowCard
import com.example.aurameter.ui.components.NeonButton
import com.example.aurameter.ui.theme.*
import kotlinx.coroutines.launch
import kotlin.random.Random

@Composable
fun DailyRouletteScreen(navController: NavController) {
    val prizes = MockRepository.roulettePrizes
    var spinsLeft by remember { mutableIntStateOf(3) }
    var isSpinning by remember { mutableStateOf(false) }
    var wonPrize by remember { mutableStateOf<RoulettePrize?>(null) }

    val coroutineScope = rememberCoroutineScope()
    val animatedRotation = remember { Animatable(0f) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(AuraDarkBackground)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // TOP HEADER
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = { navController.popBackStack() },
                    modifier = Modifier
                        .clip(CircleShape)
                        .background(AuraDarkSurface)
                ) {
                    Icon(Icons.Filled.ArrowBack, contentDescription = "Back", tint = TextPrimary)
                }

                Text(
                    text = "RULETA DIARIA DE AURA",
                    color = TextPrimary,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Black,
                    letterSpacing = 1.2.sp
                )

                Spacer(modifier = Modifier.width(48.dp))
            }

            Spacer(modifier = Modifier.height(16.dp))

            // SPINS LEFT INDICATOR
            AuraGlowCard(
                borderColor = NeonGold,
                glowColor = NeonGoldGlow
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(Icons.Filled.Casino, contentDescription = null, tint = NeonGold)
                        Text("TIROS RESTANTES HOY", color = TextSecondary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }

                    Surface(
                        color = NeonGold.copy(alpha = 0.2f),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text(
                            text = "$spinsLeft / 3",
                            color = NeonGold,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Black,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(32.dp))

            // ROULETTE CANVAS CONTAINER
            Box(
                modifier = Modifier
                    .size(320.dp)
                    .shadow(24.dp, CircleShape, spotColor = NeonCyanGlow),
                contentAlignment = Alignment.Center
            ) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val center = Offset(size.width / 2f, size.height / 2f)
                    val radius = size.minDimension / 2f
                    val sweepAngle = 360f / prizes.size

                    rotate(animatedRotation.value, pivot = center) {
                        prizes.forEachIndexed { index, prize ->
                            val startAngle = index * sweepAngle
                            drawArc(
                                color = Color(prize.colorHex),
                                startAngle = startAngle,
                                sweepAngle = sweepAngle,
                                useCenter = true,
                                size = Size(radius * 2f, radius * 2f),
                                topLeft = Offset(center.x - radius, center.y - radius)
                            )

                            drawArc(
                                color = AuraDarkBackground.copy(alpha = 0.4f),
                                startAngle = startAngle,
                                sweepAngle = sweepAngle,
                                useCenter = true,
                                style = Stroke(width = 3f),
                                size = Size(radius * 2f, radius * 2f),
                                topLeft = Offset(center.x - radius, center.y - radius)
                            )
                        }
                    }

                    // OUTER GLOW RING
                    drawCircle(
                        color = NeonCyan,
                        radius = radius,
                        style = Stroke(width = 8f)
                    )
                }

                // CENTER NEEDLE / POINTER
                Box(
                    modifier = Modifier
                        .size(60.dp)
                        .shadow(12.dp, CircleShape, spotColor = NeonGold)
                        .clip(CircleShape)
                        .background(AuraDarkSurface)
                        .border(3.dp, NeonGold, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Filled.ChangeCircle,
                        contentDescription = "Spin",
                        tint = NeonGold,
                        modifier = Modifier.size(32.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(36.dp))

            // SPIN BUTTON
            NeonButton(
                text = if (isSpinning) "GIRANDO..." else "¡GIRAR RULETA!",
                onClick = {
                    if (spinsLeft > 0 && !isSpinning) {
                        isSpinning = true
                        spinsLeft -= 1
                        val selectedIndex = Random.nextInt(prizes.size)
                        val targetDegrees = 360f * 5 + (360f - (selectedIndex * (360f / prizes.size)))

                        coroutineScope.launch {
                            animatedRotation.animateTo(
                                targetValue = targetDegrees,
                                animationSpec = tween(
                                    durationMillis = 3500,
                                    easing = FastOutSlowInEasing
                                )
                            )
                            isSpinning = false
                            val prize = prizes[selectedIndex]
                            wonPrize = prize

                            // Apply Prize to User State
                            if (prize.deltaAura != 0) {
                                MockRepository.currentUser.value = MockRepository.currentUser.value.copy(
                                    auraPoints = (MockRepository.currentUser.value.auraPoints + prize.deltaAura).coerceAtLeast(0)
                                )
                            }
                        }
                    }
                },
                enabled = spinsLeft > 0 && !isSpinning,
                neonColor = NeonCyan,
                glowColor = NeonCyanGlow
            )
        }

        // WINNER PRIZE DIALOG
        wonPrize?.let { prize ->
            AlertDialog(
                onDismissRequest = { wonPrize = null },
                containerColor = AuraDarkSurface,
                title = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            Icons.Filled.EmojiEvents,
                            contentDescription = null,
                            tint = if (prize.isRisk) NeonCrimson else NeonGold
                        )
                        Text(
                            text = if (prize.isRisk) "¡PENALIZACIÓN!" else "¡PREMIO OBTENIDO!",
                            color = if (prize.isRisk) NeonCrimson else NeonGold,
                            fontWeight = FontWeight.Black
                        )
                    }
                },
                text = {
                    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                        Text(prize.label, color = TextPrimary, fontSize = 22.sp, fontWeight = FontWeight.Black)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(prize.rewardText, color = TextSecondary, fontSize = 13.sp)
                    }
                },
                confirmButton = {
                    NeonButton(
                        text = "RECLAMAR",
                        onClick = { wonPrize = null },
                        neonColor = NeonGold,
                        glowColor = NeonGoldGlow
                    )
                }
            )
        }
    }
}
