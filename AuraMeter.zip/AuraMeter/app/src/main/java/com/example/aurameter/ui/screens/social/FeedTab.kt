package com.example.aurameter.ui.screens.social

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.ChatBubbleOutline
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material.icons.outlined.Repeat
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.aurameter.data.MockRepository
import com.example.aurameter.data.Post
import com.example.aurameter.ui.components.AuraGlowCard
import com.example.aurameter.ui.theme.*

@Composable
fun FeedTab() {
    val posts = MockRepository.feedPosts
    var newPostText by remember { mutableStateOf("") }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        contentPadding = PaddingValues(vertical = 16.dp)
    ) {
        // PUBLISH NEW AURA STREAK POST CARD
        item {
            AuraGlowCard(
                borderColor = NeonCyan,
                glowColor = NeonCyanGlow
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .clip(CircleShape)
                            .background(NeonPurple)
                            .border(1.dp, NeonCyan, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("K", color = TextPrimary, fontWeight = FontWeight.Black)
                    }

                    TextField(
                        value = newPostText,
                        onValueChange = { newPostText = it },
                        placeholder = { Text("¡Comparte tu racha de Aura o desafío!", color = TextMuted) },
                        modifier = Modifier.weight(1f),
                        colors = TextFieldDefaults.colors(
                            focusedContainerColor = Color.Transparent,
                            unfocusedContainerColor = Color.Transparent,
                            focusedIndicatorColor = Color.Transparent,
                            unfocusedIndicatorColor = Color.Transparent,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary
                        )
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Surface(
                            color = NeonPink.copy(alpha = 0.2f),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Filled.LocalFireDepartment, contentDescription = null, tint = NeonPink, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Racha +18", color = NeonPink, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }

                    Button(
                        onClick = {
                            if (newPostText.isNotBlank()) {
                                posts.add(
                                    0,
                                    Post(
                                        id = "post_${System.currentTimeMillis()}",
                                        authorName = "Kaelen Voss",
                                        authorUsername = "@kaelen_aura",
                                        authorAvatar = "https://i.pravatar.cc/300?img=12",
                                        authorAura = MockRepository.currentUser.value.auraPoints,
                                        content = newPostText,
                                        auraStreakDays = MockRepository.currentUser.value.streakDays,
                                        auraEarned = 2500,
                                        likesCount = 1,
                                        commentsCount = 0,
                                        repostsCount = 0,
                                        timeAgo = "Ahora",
                                        isLiked = true
                                    )
                                )
                                newPostText = ""
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = NeonCyan),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text("PUBLICAR", color = AuraDarkBackground, fontWeight = FontWeight.Black)
                    }
                }
            }
        }

        // POSTS LIST
        items(posts, key = { it.id }) { post ->
            AuraPostCard(post = post)
        }
    }
}

@Composable
private fun AuraPostCard(post: Post) {
    var isLiked by remember { mutableStateOf(post.isLiked) }
    var likesCount by remember { mutableIntStateOf(post.likesCount) }

    AuraGlowCard(
        borderColor = NeonPurple,
        glowColor = NeonPurpleGlow
    ) {
        // Author Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(42.dp)
                        .clip(CircleShape)
                        .background(
                            brush = Brush.linearGradient(listOf(NeonPurple, NeonPink))
                        )
                        .border(1.dp, NeonCyan, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Text(post.authorName.take(1), color = TextPrimary, fontWeight = FontWeight.Black)
                }

                Column {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(post.authorName, color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Text(post.authorUsername, color = TextMuted, fontSize = 12.sp)
                    }
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text("${post.authorAura} AURA", color = NeonCyan, fontSize = 11.sp, fontWeight = FontWeight.ExtraBold)
                        Text("• ${post.timeAgo}", color = TextMuted, fontSize = 11.sp)
                    }
                }
            }

            // Streak Badge
            Surface(
                color = NeonPink.copy(alpha = 0.2f),
                shape = RoundedCornerShape(12.dp)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Filled.LocalFireDepartment, contentDescription = null, tint = NeonPink, modifier = Modifier.size(14.dp))
                    Text("${post.auraStreakDays}d", color = NeonPink, fontSize = 11.sp, fontWeight = FontWeight.Black)
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Content
        Text(
            text = post.content,
            color = TextPrimary,
            fontSize = 14.sp,
            lineHeight = 20.sp
        )

        Spacer(modifier = Modifier.height(12.dp))

        // Aura Earned Banner
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(10.dp))
                .background(AuraGlassOverlay)
                .padding(horizontal = 10.dp, vertical = 6.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Icon(Icons.Filled.Bolt, contentDescription = null, tint = NeonGold, modifier = Modifier.size(16.dp))
                Text("Cosechado en este post: +${post.auraEarned} AURA", color = NeonGold, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Actions: Like, Comment, Repost
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.clickable {
                    isLiked = !isLiked
                    likesCount += if (isLiked) 1 else -1
                }
            ) {
                Icon(
                    imageVector = if (isLiked) Icons.Filled.Favorite else Icons.Outlined.FavoriteBorder,
                    contentDescription = "Like",
                    tint = if (isLiked) NeonPink else TextMuted,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text("$likesCount", color = if (isLiked) NeonPink else TextMuted, fontSize = 12.sp)
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Outlined.ChatBubbleOutline, contentDescription = "Comments", tint = TextMuted, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("${post.commentsCount}", color = TextMuted, fontSize = 12.sp)
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Outlined.Repeat, contentDescription = "Reposts", tint = TextMuted, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("${post.repostsCount}", color = TextMuted, fontSize = 12.sp)
            }

            Icon(Icons.Filled.Share, contentDescription = "Share", tint = TextMuted, modifier = Modifier.size(18.dp))
        }
    }
}
