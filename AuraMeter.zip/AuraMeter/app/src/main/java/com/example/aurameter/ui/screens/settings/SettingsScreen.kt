package com.example.aurameter.ui.screens.settings

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.ExitToApp
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.aurameter.data.MockRepository
import com.example.aurameter.ui.components.AuraGlowCard
import com.example.aurameter.ui.components.NeonButton
import com.example.aurameter.ui.navigation.Screen
import com.example.aurameter.ui.theme.*

@Composable
fun SettingsScreen(navController: NavController) {
    val currentUser by MockRepository.currentUser

    var notificationsEnabled by remember { mutableStateOf(true) }
    var stealthModeEnabled by remember { mutableStateOf(false) }
    var soundEffectsEnabled by remember { mutableStateOf(true) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(AuraDarkBackground)
    ) {
        Column(
            modifier = Modifier.fillMaxSize()
        ) {
            // HEADER
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                Text(
                    text = "AJUSTES DE PERFIL Y RED",
                    color = TextPrimary,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Black,
                    letterSpacing = 1.2.sp,
                    modifier = Modifier.align(Alignment.Center)
                )
            }

            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // USER PROFILE OVERVIEW CARD
                item {
                    AuraGlowCard(
                        borderColor = NeonCyan,
                        glowColor = NeonCyanGlow
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(16.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(64.dp)
                                    .shadow(12.dp, CircleShape, spotColor = NeonPurple)
                                    .clip(CircleShape)
                                    .background(
                                        brush = Brush.linearGradient(listOf(NeonPurple, NeonPink))
                                    )
                                    .border(2.dp, NeonCyan, CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = currentUser.name.take(1),
                                    color = TextPrimary,
                                    fontSize = 24.sp,
                                    fontWeight = FontWeight.Black
                                )
                            }

                            Column {
                                Text(currentUser.name, color = TextPrimary, fontSize = 18.sp, fontWeight = FontWeight.Black)
                                Text(currentUser.username, color = TextMuted, fontSize = 13.sp)
                                Spacer(modifier = Modifier.height(4.dp))
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Icon(Icons.Filled.Bolt, contentDescription = null, tint = NeonCyan, modifier = Modifier.size(16.dp))
                                    Text("${currentUser.auraPoints} AURA", color = NeonCyan, fontSize = 14.sp, fontWeight = FontWeight.Black)
                                }
                            }
                        }
                    }
                }

                // PREFERENCES SETTINGS
                item {
                    Text(
                        text = "CONFIGURACIÓN DE AURA",
                        color = TextPrimary,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Black,
                        letterSpacing = 1.sp
                    )
                }

                item {
                    AuraGlowCard(
                        borderColor = NeonPurple,
                        glowColor = NeonPurpleGlow
                    ) {
                        SettingToggleRow(
                            icon = Icons.Filled.Notifications,
                            title = "Notificaciones de Batalla",
                            subtitle = "Alertas cuando te desafíen o regalen Aura",
                            checked = notificationsEnabled,
                            onCheckedChange = { notificationsEnabled = it }
                        )

                        HorizontalDivider(modifier = Modifier.padding(vertical = 12.dp), color = AuraGlassOverlay)

                        SettingToggleRow(
                            icon = Icons.Filled.Security,
                            title = "Modo Sigiloso en Mapa",
                            subtitle = "Ocultar posición en el Heatmap radar",
                            checked = stealthModeEnabled,
                            onCheckedChange = { stealthModeEnabled = it }
                        )

                        HorizontalDivider(modifier = Modifier.padding(vertical = 12.dp), color = AuraGlassOverlay)

                        SettingToggleRow(
                            icon = Icons.Filled.Palette,
                            title = "Efectos Neón de Sonido",
                            subtitle = "Sonidos al ganar o girar la ruleta",
                            checked = soundEffectsEnabled,
                            onCheckedChange = { soundEffectsEnabled = it }
                        )
                    }
                }

                // LOGOUT BUTTON
                item {
                    Spacer(modifier = Modifier.height(16.dp))
                    NeonButton(
                        text = "CERRAR SESIÓN",
                        onClick = {
                            navController.navigate(Screen.Auth.route) {
                                popUpTo(0) { inclusive = true }
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                        neonColor = NeonPink,
                        glowColor = NeonPinkGlow,
                        leadingIcon = { Icon(Icons.Filled.ExitToApp, contentDescription = null, tint = AuraDarkBackground) }
                    )
                }
            }
        }
    }
}

@Composable
private fun SettingToggleRow(
    icon: ImageVector,
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(
            modifier = Modifier.weight(1f),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(imageVector = icon, contentDescription = null, tint = NeonCyan, modifier = Modifier.size(22.dp))
            Column {
                Text(title, color = TextPrimary, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                Text(subtitle, color = TextMuted, fontSize = 11.sp)
            }
        }

        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = AuraDarkBackground,
                checkedTrackColor = NeonCyan,
                uncheckedThumbColor = TextMuted,
                uncheckedTrackColor = AuraDarkSurface
            )
        )
    }
}
