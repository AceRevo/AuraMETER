package com.example.aurameter.data

data class UserProfile(
    val id: String,
    val name: String,
    val username: String,
    val avatarUrl: String,
    val auraPoints: Long,
    val globalRank: Int,
    val levelTitle: String,
    val auraMultiplier: Float,
    val streakDays: Int,
    val clanName: String?
)

data class DailyChallenge(
    val id: String,
    val title: String,
    val description: String,
    val rewardAura: Int,
    val rewardMultiplier: String,
    val isCompleted: Boolean,
    val category: String,
    val iconName: String
)

data class Post(
    val id: String,
    val authorName: String,
    val authorUsername: String,
    val authorAvatar: String,
    val authorAura: Long,
    val content: String,
    val auraStreakDays: Int,
    val auraEarned: Int,
    val likesCount: Int,
    val commentsCount: Int,
    val repostsCount: Int,
    val timeAgo: String,
    val isLiked: Boolean = false,
    val imageUrl: String? = null
)

data class ShortVideo(
    val id: String,
    val creatorName: String,
    val creatorAvatar: String,
    val creatorRank: Int,
    val battleTitle: String,
    val auraStakes: Long,
    val gradientColorsHex: List<Long>,
    val likesCount: Int,
    val commentsCount: Int,
    val sharesCount: Int,
    val isFollowing: Boolean = false,
    val isLiked: Boolean = false
)

data class ChatMessage(
    val id: String,
    val senderId: String,
    val senderName: String,
    val text: String,
    val timestamp: String,
    val isFromMe: Boolean,
    val auraGifted: Int? = null,
    val isSystemNotice: Boolean = false
)

data class Contact(
    val id: String,
    val name: String,
    val username: String,
    val avatarUrl: String,
    val auraPoints: Long,
    val rank: Int,
    val activeMission: String,
    val isOnline: Boolean,
    val lastMessage: String,
    val lastMessageTime: String
)

data class Clan(
    val id: String,
    val name: String,
    val tag: String,
    val emblemIcon: String,
    val totalAura: Long,
    val memberCount: Int,
    val maxMembers: Int,
    val rank: Int,
    val description: String,
    val leaderName: String,
    val isUserMember: Boolean = false
)

data class ClanMission(
    val id: String,
    val title: String,
    val currentProgress: Int,
    val maxProgress: Int,
    val rewardAura: Long,
    val daysRemaining: Int
)

data class ClanMember(
    val id: String,
    val name: String,
    val role: String,
    val auraContributed: Long,
    val rank: Int,
    val isOnline: Boolean
)

data class LeaderboardUser(
    val rank: Int,
    val id: String,
    val name: String,
    val username: String,
    val avatarUrl: String,
    val totalAura: Long,
    val weeklyGain: Long,
    val badgeTitle: String,
    val isLeader: Boolean = false,
    val rankChange: Int = 0 // +2, -1, 0
)

data class RoulettePrize(
    val id: String,
    val label: String,
    val rewardText: String,
    val deltaAura: Int,
    val multiplier: Float,
    val isRisk: Boolean,
    val colorHex: Long
)

data class RadarUser(
    val id: String,
    val name: String,
    val auraPoints: Long,
    val rank: Int,
    val distanceMeters: Int,
    val xRatio: Float, // 0.0 - 1.0 relative map position
    val yRatio: Float,
    val auraTitle: String
)

data class HeatZone(
    val id: String,
    val name: String,
    val intensity: Float, // 0.2 to 1.0
    val activeUsers: Int,
    val xRatio: Float,
    val yRatio: Float,
    val radiusPx: Float
)
