package com.example.aurameter.ui.screens.clans

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Group
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.aurameter.data.Clan
import com.example.aurameter.data.MockRepository
import com.example.aurameter.ui.components.AuraGlowCard
import com.example.aurameter.ui.components.NeonButton
import com.example.aurameter.ui.theme.*

@Composable
fun ClanSystemScreen(navController: NavController) {
    val clans = MockRepository.clans
    val missions = MockRepository.clanMissions
    val members = MockRepository.clanMembers
    var selectedClan by remember { mutableStateOf<Clan?>(clans.first()) }
    var joinRequested by remember { mutableStateOf(false) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(AuraDarkBackground)
    ) {
        Column(
            modifier = Modifier.fillMaxSize()
        ) {
            // HEADER
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = { navController.popBackStack() },
                    modifier = Modifier
                        .clip(CircleShape)
                        .background(AuraDarkSurface)
                ) {
                    Icon(Icons.Filled.ArrowBack, contentDescription = "Back", tint = TextPrimary)
                }

                Text(
                    text = "SISTEMA DE CLANES",
                    color = TextPrimary,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Black,
                    letterSpacing = 1.2.sp
                )

                Spacer(modifier = Modifier.width(48.dp))
            }

            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // CLAN SELECTOR LIST
                item {
                    Text(
                        text = "CLANES DESTACADOS & AURA COMUNITARIA",
                        color = TextPrimary,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Black,
                        letterSpacing = 1.sp
                    )
                }

                items(clans, key = { it.id }) { clan ->
                    ClanCardItem(
                        clan = clan,
                        isSelected = selectedClan?.id == clan.id,
                        onClick = { selectedClan = clan }
                    )
                }

                // SELECTED CLAN PROFILE & DETAIL
                selectedClan?.let { clan ->
                    item {
                        Spacer(modifier = Modifier.height(8.dp))
                        AuraGlowCard(
                            borderColor = NeonGold,
                            glowColor = NeonGoldGlow
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        Text(clan.name, color = TextPrimary, fontSize = 18.sp, fontWeight = FontWeight.Black)
                                        Surface(color = NeonCyan.copy(alpha = 0.2f), shape = RoundedCornerShape(8.dp)) {
                                            Text("[${clan.tag}]", color = NeonCyan, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
                                        }
                                    }
                                    Text("Líder: ${clan.leaderName} • ${clan.memberCount}/${clan.maxMembers} Miembros", color = TextSecondary, fontSize = 12.sp)
                                }

                                if (clan.isUserMember) {
                                    Surface(color = NeonEmerald.copy(alpha = 0.2f), shape = RoundedCornerShape(12.dp)) {
                                        Text("MIEMBRO ✓", color = NeonEmerald, fontSize = 11.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp))
                                    }
                                } else {
                                    NeonButton(
                                        text = if (joinRequested) "SOLICITADO" else "SOLICITAR UNIÓN",
                                        onClick = { joinRequested = true },
                                        enabled = !joinRequested,
                                        neonColor = NeonCyan,
                                        glowColor = NeonCyanGlow
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(10.dp))
                            Text(clan.description, color = TextMuted, fontSize = 12.sp)
                        }
                    }

                    // JOINT CLAN MISSIONS
                    item {
                        Text(
                            text = "MISIONES CONJUNTAS DE CLAN",
                            color = TextPrimary,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Black,
                            letterSpacing = 1.sp
                        )
                    }

                    items(missions, key = { it.id }) { mission ->
                        AuraGlowCard(
                            borderColor = NeonPurple,
                            glowColor = NeonPurpleGlow
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(mission.title, color = TextPrimary, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                                Text("+${mission.rewardAura} AURA", color = NeonGold, fontSize = 12.sp, fontWeight = FontWeight.Black)
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            LinearProgressIndicator(
                                progress = { mission.currentProgress.toFloat() / mission.maxProgress },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(8.dp)
                                    .clip(RoundedCornerShape(4.dp)),
                                color = NeonCyan,
                                trackColor = AuraDarkSurface
                            )

                            Spacer(modifier = Modifier.height(6.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("Progreso: ${mission.currentProgress}/${mission.maxProgress}", color = TextSecondary, fontSize = 11.sp)
                                Text("Restan: ${mission.daysRemaining} días", color = TextMuted, fontSize = 11.sp)
                            }
                        }
                    }

                    // MEMBER ROSTER
                    item {
                        Text(
                            text = "ROSTER DE MIEMBROS",
                            color = TextPrimary,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Black,
                            letterSpacing = 1.sp
                        )
                    }

                    items(members, key = { it.id }) { member ->
                        Surface(
                            modifier = Modifier.fillMaxWidth(),
                            color = AuraCardSurface,
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(36.dp)
                                            .clip(CircleShape)
                                            .background(NeonPurple),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(member.name.take(1), color = TextPrimary, fontWeight = FontWeight.Black)
                                    }

                                    Column {
                                        Text(member.name, color = TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                        Text(member.role, color = TextMuted, fontSize = 10.sp)
                                    }
                                }

                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Icon(Icons.Filled.Bolt, contentDescription = null, tint = NeonCyan, modifier = Modifier.size(14.dp))
                                    Text("${member.auraContributed} AURA", color = NeonCyan, fontSize = 12.sp, fontWeight = FontWeight.Black)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ClanCardItem(
    clan: Clan,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    AuraGlowCard(
        borderColor = if (isSelected) NeonGold else NeonCyan,
        glowColor = if (isSelected) NeonGoldGlow else NeonCyanGlow,
        modifier = Modifier.clickable(onClick = onClick)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(48.dp)
                        .clip(CircleShape)
                        .background(
                            brush = Brush.linearGradient(listOf(NeonCyan, NeonPurple))
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Filled.Shield, contentDescription = null, tint = AuraDarkBackground)
                }

                Column {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(clan.name, color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                        Surface(color = NeonCyan.copy(alpha = 0.2f), shape = RoundedCornerShape(6.dp)) {
                            Text("#${clan.rank}", color = NeonCyan, fontSize = 10.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
                        }
                    }

                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        Icon(Icons.Filled.Bolt, contentDescription = null, tint = NeonGold, modifier = Modifier.size(14.dp))
                        Text("Aura Comunitaria: ${clan.totalAura}", color = NeonGold, fontSize = 12.sp, fontWeight = FontWeight.Black)
                    }
                }
            }

            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                Icon(Icons.Filled.Group, contentDescription = null, tint = TextMuted, modifier = Modifier.size(14.dp))
                Text("${clan.memberCount}/${clan.maxMembers}", color = TextMuted, fontSize = 12.sp)
            }
        }
    }
}
