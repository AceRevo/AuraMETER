package com.example.aurameter.ui.theme

import android.app.Activity
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private val AuraColorScheme = darkColorScheme(
    primary = NeonCyan,
    onPrimary = AuraDarkBackground,
    primaryContainer = AuraCardSurface,
    onPrimaryContainer = NeonCyan,
    secondary = NeonPurple,
    onSecondary = TextPrimary,
    secondaryContainer = AuraGlassOverlay,
    onSecondaryContainer = NeonPink,
    tertiary = NeonGold,
    onTertiary = AuraDarkBackground,
    background = AuraDarkBackground,
    onBackground = TextPrimary,
    surface = AuraDarkSurface,
    onSurface = TextPrimary,
    surfaceVariant = AuraCardSurface,
    onSurfaceVariant = TextSecondary,
    error = NeonCrimson
)

@Composable
fun AuraMeterTheme(
    content: @Composable () -> Unit
) {
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            window.statusBarColor = AuraDarkBackground.toArgb()
            window.navigationBarColor = AuraDarkBackground.toArgb()
            WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = false
            WindowCompat.getInsetsController(window, view).isAppearanceLightNavigationBars = false
        }
    }

    MaterialTheme(
        colorScheme = AuraColorScheme,
        typography = Typography,
        content = content
    )
}