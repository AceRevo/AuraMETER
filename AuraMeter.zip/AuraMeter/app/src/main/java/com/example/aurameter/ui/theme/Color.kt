package com.example.aurameter.ui.theme

import androidx.compose.ui.graphics.Color

// Neon & Cyberpunk Dark Aura Palette
val AuraDarkBackground = Color(0xFF090710)
val AuraDarkSurface = Color(0xFF130E22)
val AuraCardSurface = Color(0xFF1E1635)
val AuraGlassOverlay = Color(0x332E2250)

// Neon Accents
val NeonCyan = Color(0xFF00F0FF)
val NeonCyanGlow = Color(0x6600F0FF)
val NeonPurple = Color(0xFFB026FF)
val NeonPurpleGlow = Color(0x66B026FF)
val NeonPink = Color(0xFFFF007A)
val NeonPinkGlow = Color(0x66FF007A)
val NeonGold = Color(0xFFFFD700)
val NeonGoldGlow = Color(0x66FFD700)
val NeonEmerald = Color(0xFF00FF88)
val NeonEmeraldGlow = Color(0x6600FF88)
val NeonCrimson = Color(0xFFFF2A4B)

// Text Colors
val TextPrimary = Color(0xFFF1F0F7)
val TextSecondary = Color(0xFFA59EB5)
val TextMuted = Color(0xFF6B6380)
