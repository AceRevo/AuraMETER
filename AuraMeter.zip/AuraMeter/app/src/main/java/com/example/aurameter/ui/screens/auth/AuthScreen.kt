package com.example.aurameter.ui.screens.auth

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.aurameter.ui.components.AuraGlowCard
import com.example.aurameter.ui.components.NeonButton
import com.example.aurameter.ui.navigation.Screen
import com.example.aurameter.ui.theme.*

@Composable
fun AuthScreen(navController: NavController) {
    var isRegisterTab by remember { mutableStateOf(false) }

    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var username by remember { mutableStateOf("") }
    var auraTitleChoice by remember { mutableStateOf("Guerrero Neón") }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(AuraDarkBackground),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // GLOWING LOGO ICON
            Box(
                modifier = Modifier
                    .size(80.dp)
                    .shadow(20.dp, CircleShape, spotColor = NeonCyanGlow)
                    .clip(CircleShape)
                    .background(
                        brush = Brush.linearGradient(listOf(NeonCyan, NeonPurple))
                    )
                    .border(2.dp, NeonGold, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Filled.Bolt,
                    contentDescription = "Aura Meter Logo",
                    tint = AuraDarkBackground,
                    modifier = Modifier.size(48.dp)
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            Text(
                text = "AURA-METRE",
                color = TextPrimary,
                fontSize = 28.sp,
                fontWeight = FontWeight.Black,
                letterSpacing = 2.sp
            )

            Text(
                text = "MIDE, ACUMULA Y COMPITE POR TU AURA",
                color = NeonCyan,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp
            )

            Spacer(modifier = Modifier.height(28.dp))

            // AUTH FORM CARD
            AuraGlowCard(
                borderColor = NeonCyan,
                glowColor = NeonCyanGlow
            ) {
                // TOGGLE TABS: LOGIN / REGISTRO
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(AuraDarkSurface)
                        .padding(4.dp)
                ) {
                    Surface(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(10.dp)),
                        color = if (!isRegisterTab) NeonCyan else Color.Transparent,
                        onClick = { isRegisterTab = false }
                    ) {
                        Box(modifier = Modifier.padding(vertical = 8.dp), contentAlignment = Alignment.Center) {
                            Text("INICIAR SESIÓN", color = if (!isRegisterTab) AuraDarkBackground else TextMuted, fontWeight = FontWeight.Black, fontSize = 12.sp)
                        }
                    }

                    Surface(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(10.dp)),
                        color = if (isRegisterTab) NeonCyan else Color.Transparent,
                        onClick = { isRegisterTab = true }
                    ) {
                        Box(modifier = Modifier.padding(vertical = 8.dp), contentAlignment = Alignment.Center) {
                            Text("REGISTRARSE", color = if (isRegisterTab) AuraDarkBackground else TextMuted, fontWeight = FontWeight.Black, fontSize = 12.sp)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                if (isRegisterTab) {
                    TextField(
                        value = username,
                        onValueChange = { username = it },
                        label = { Text("Nombre de Usuario", color = TextMuted) },
                        leadingIcon = { Icon(Icons.Filled.Person, contentDescription = null, tint = NeonCyan) },
                        modifier = Modifier.fillMaxWidth(),
                        colors = TextFieldDefaults.colors(
                            focusedContainerColor = AuraDarkSurface,
                            unfocusedContainerColor = AuraDarkSurface,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary
                        )
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                }

                TextField(
                    value = email,
                    onValueChange = { email = it },
                    label = { Text("Correo Electrónico", color = TextMuted) },
                    leadingIcon = { Icon(Icons.Filled.Email, contentDescription = null, tint = NeonCyan) },
                    modifier = Modifier.fillMaxWidth(),
                    colors = TextFieldDefaults.colors(
                        focusedContainerColor = AuraDarkSurface,
                        unfocusedContainerColor = AuraDarkSurface,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary
                    )
                )

                Spacer(modifier = Modifier.height(12.dp))

                TextField(
                    value = password,
                    onValueChange = { password = it },
                    label = { Text("Contraseña", color = TextMuted) },
                    leadingIcon = { Icon(Icons.Filled.Lock, contentDescription = null, tint = NeonCyan) },
                    visualTransformation = PasswordVisualTransformation(),
                    modifier = Modifier.fillMaxWidth(),
                    colors = TextFieldDefaults.colors(
                        focusedContainerColor = AuraDarkSurface,
                        unfocusedContainerColor = AuraDarkSurface,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary
                    )
                )

                Spacer(modifier = Modifier.height(24.dp))

                NeonButton(
                    text = if (isRegisterTab) "MIDE TU AURA Y REGÍSTRATE" else "ENTRAR AL ECOSISTEMA",
                    onClick = {
                        navController.navigate(Screen.Home.route) {
                            popUpTo(Screen.Auth.route) { inclusive = true }
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                    neonColor = NeonCyan,
                    glowColor = NeonCyanGlow
                )
            }
        }
    }
}
