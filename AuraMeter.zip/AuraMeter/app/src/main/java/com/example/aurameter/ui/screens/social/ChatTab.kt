package com.example.aurameter.ui.screens.social

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Group
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.aurameter.data.Contact
import com.example.aurameter.data.MockRepository
import com.example.aurameter.ui.components.AuraGlowCard
import com.example.aurameter.ui.navigation.Screen
import com.example.aurameter.ui.theme.*

@Composable
fun ChatTab(navController: NavController) {
    val contacts = MockRepository.contacts

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        contentPadding = PaddingValues(vertical = 16.dp)
    ) {
        // GLOBAL AMINO-STYLE CHAT ROOM BANNER
        item {
            AuraGlowCard(
                borderColor = NeonCyan,
                glowColor = NeonCyanGlow
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(48.dp)
                                .clip(CircleShape)
                                .background(
                                    brush = Brush.linearGradient(listOf(NeonCyan, NeonPurple))
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Filled.Group, contentDescription = null, tint = AuraDarkBackground)
                        }

                        Column {
                            Text(
                                text = "CHAT GLOBAL AURA",
                                color = TextPrimary,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Black
                            )
                            Text(
                                text = "1,420 Guerreros Conectados",
                                color = NeonEmerald,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Button(
                        onClick = { navController.navigate(Screen.DirectChatDetail.createRoute("c_nova")) },
                        colors = ButtonDefaults.buttonColors(containerColor = NeonCyan),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text("ENTRAR", color = AuraDarkBackground, fontWeight = FontWeight.Black, fontSize = 12.sp)
                    }
                }
            }
        }

        // DIRECT MESSAGES HEADER
        item {
            Text(
                text = "MENSAJES DIRECTOS",
                color = TextPrimary,
                fontSize = 14.sp,
                fontWeight = FontWeight.Black,
                letterSpacing = 1.2.sp
            )
        }

        // CONTACTS LIST
        items(contacts, key = { it.id }) { contact ->
            ContactChatItem(
                contact = contact,
                onClick = { navController.navigate(Screen.DirectChatDetail.createRoute(contact.id)) }
            )
        }
    }
}

@Composable
private fun ContactChatItem(
    contact: Contact,
    onClick: () -> Unit
) {
    AuraGlowCard(
        borderColor = if (contact.isOnline) NeonEmerald else NeonPurple,
        glowColor = if (contact.isOnline) NeonEmeraldGlow else NeonPurpleGlow,
        modifier = Modifier.clickable(onClick = onClick)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                modifier = Modifier.weight(1f),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Avatar with Online Badge
                Box(contentAlignment = Alignment.BottomEnd) {
                    Box(
                        modifier = Modifier
                            .size(46.dp)
                            .clip(CircleShape)
                            .background(
                                brush = Brush.linearGradient(listOf(NeonPurple, NeonPink))
                            )
                            .border(1.dp, NeonCyan, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(contact.name.take(1), color = TextPrimary, fontWeight = FontWeight.Black, fontSize = 18.sp)
                    }

                    if (contact.isOnline) {
                        Box(
                            modifier = Modifier
                                .size(12.dp)
                                .clip(CircleShape)
                                .background(NeonEmerald)
                                .border(2.dp, AuraDarkSurface, CircleShape)
                        )
                    }
                }

                Column {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(contact.name, color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Surface(
                            color = NeonGold.copy(alpha = 0.2f),
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Text(
                                text = "#${contact.rank}",
                                color = NeonGold,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.ExtraBold,
                                modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                            )
                        }
                    }

                    Text(
                        text = contact.lastMessage,
                        color = TextSecondary,
                        fontSize = 12.sp,
                        maxLines = 1
                    )

                    Spacer(modifier = Modifier.height(2.dp))

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(Icons.Filled.Bolt, contentDescription = null, tint = NeonCyan, modifier = Modifier.size(12.dp))
                        Text("${contact.auraPoints} AURA", color = NeonCyan, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }

            Text(contact.lastMessageTime, color = TextMuted, fontSize = 10.sp)
        }
    }
}
