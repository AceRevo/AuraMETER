package com.example.aurameter

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.example.aurameter.ui.navigation.AuraNavGraph
import com.example.aurameter.ui.theme.AuraMeterTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            AuraMeterTheme {
                AuraNavGraph()
            }
        }
    }
}
