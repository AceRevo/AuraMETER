package com.example.aurameter.ui.screens.map

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.MyLocation
import androidx.compose.material.icons.filled.Radar
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.aurameter.data.MockRepository
import com.example.aurameter.data.RadarUser
import com.example.aurameter.ui.components.NeonButton
import com.example.aurameter.ui.theme.*

@Composable
fun AuraMapScreen(navController: NavController) {
    val heatZones = MockRepository.heatZones
    val radarUsers = MockRepository.radarUsers
    var selectedUser by remember { mutableStateOf<RadarUser?>(null) }

    // Radar Scanning Animation
    var isScanning by remember { mutableStateOf(false) }
    val infiniteTransition = rememberInfiniteTransition(label = "radarSweep")
    val sweepAngle by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(2500, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "angle"
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(AuraDarkBackground)
    ) {
        // SIMULATED GEOLOCATED CANVAS MAP WITH HEAT ZONES & RADAR SWEEP
        Canvas(
            modifier = Modifier.fillMaxSize()
        ) {
            val width = size.width
            val height = size.height

            // Cyber Grid Lines
            val gridSpacing = 60f
            var x = 0f
            while (x < width) {
                drawLine(
                    color = Color(0xFF1E1635),
                    start = Offset(x, 0f),
                    end = Offset(x, height),
                    strokeWidth = 1f
                )
                x += gridSpacing
            }
            var y = 0f
            while (y < height) {
                drawLine(
                    color = Color(0xFF1E1635),
                    start = Offset(0f, y),
                    end = Offset(width, y),
                    strokeWidth = 1f
                )
                y += gridSpacing
            }

            // RADIANT HEAT ZONES (Brighter = More aura density)
            heatZones.forEach { zone ->
                val centerPx = Offset(zone.xRatio * width, zone.yRatio * height)
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(
                            NeonPink.copy(alpha = 0.6f * zone.intensity),
                            NeonPurple.copy(alpha = 0.3f * zone.intensity),
                            Color.Transparent
                        ),
                        center = centerPx,
                        radius = zone.radiusPx * 2.5f
                    ),
                    center = centerPx,
                    radius = zone.radiusPx * 2.5f
                )
            }

            // RADAR CONCENTRIC RINGS
            val centerMap = Offset(width / 2f, height / 2f)
            listOf(200f, 400f, 600f, 800f).forEach { radius ->
                drawCircle(
                    color = NeonCyan.copy(alpha = 0.2f),
                    center = centerMap,
                    radius = radius,
                    style = Stroke(width = 1.5f)
                )
            }

            // RADAR SWEEP CONE
            if (isScanning) {
                drawArc(
                    brush = Brush.sweepGradient(
                        colors = listOf(
                            Color.Transparent,
                            NeonCyan.copy(alpha = 0.4f),
                            Color.Transparent
                        ),
                        center = centerMap
                    ),
                    startAngle = sweepAngle,
                    sweepAngle = 60f,
                    useCenter = true,
                    topLeft = Offset(centerMap.x - 600f, centerMap.y - 600f),
                    size = androidx.compose.ui.geometry.Size(1200f, 1200f)
                )
            }

            // USER CENTER MARKER
            drawCircle(
                color = NeonCyan,
                center = centerMap,
                radius = 12f
            )
            drawCircle(
                color = NeonCyan.copy(alpha = 0.4f),
                center = centerMap,
                radius = 24f,
                style = Stroke(width = 2f)
            )
        }

        // OVERLAY MARKERS FOR NEARBY USERS
        radarUsers.forEach { user ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
            ) {
                Box(
                    modifier = Modifier
                        .offset(
                            x = (user.xRatio * 320).dp,
                            y = (user.yRatio * 500).dp
                        )
                        .shadow(12.dp, CircleShape, spotColor = NeonPink)
                        .clip(CircleShape)
                        .background(
                            brush = Brush.linearGradient(listOf(NeonPink, NeonPurple))
                        )
                        .border(2.dp, NeonCyan, CircleShape)
                        .clickable { selectedUser = user }
                        .padding(8.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Filled.Bolt,
                        contentDescription = user.name,
                        tint = NeonGold,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        }

        // TOP HEADER BAR
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = { navController.popBackStack() },
                modifier = Modifier
                    .clip(CircleShape)
                    .background(AuraDarkSurface)
            ) {
                Icon(Icons.Filled.ArrowBack, contentDescription = "Back", tint = TextPrimary)
            }

            Surface(
                color = AuraDarkSurface,
                shape = RoundedCornerShape(20.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, NeonCyan)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(Icons.Filled.MyLocation, contentDescription = null, tint = NeonCyan, modifier = Modifier.size(18.dp))
                    Text("RADAR DE AURA EN VIVO", color = TextPrimary, fontWeight = FontWeight.Black, fontSize = 13.sp)
                }
            }
        }

        // FLOATING BUTTON: SCAN RADAR
        Box(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 90.dp)
        ) {
            NeonButton(
                text = if (isScanning) "ESCANEANDO..." else "ESCANEAR RADAR DE BATALLA",
                onClick = { isScanning = !isScanning },
                neonColor = NeonCyan,
                glowColor = NeonCyanGlow,
                leadingIcon = { Icon(Icons.Filled.Radar, contentDescription = null, tint = AuraDarkBackground) }
            )
        }

        // CHALLENGE NEARBY USER DIALOG MODAL
        selectedUser?.let { user ->
            AlertDialog(
                onDismissRequest = { selectedUser = null },
                containerColor = AuraDarkSurface,
                title = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(Icons.Filled.Bolt, contentDescription = null, tint = NeonGold)
                        Text(user.name, color = TextPrimary, fontWeight = FontWeight.Black)
                    }
                },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Título: ${user.auraTitle}", color = NeonPink, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        Text("Distancia: ${user.distanceMeters} metros", color = TextSecondary, fontSize = 12.sp)
                        Text("Reserva de Aura: ${user.auraPoints} AURA", color = NeonCyan, fontWeight = FontWeight.Black, fontSize = 14.sp)
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("¿Deseas desafiar a este usuario a un Duelo de Aura en tiempo real?", color = TextPrimary, fontSize = 13.sp)
                    }
                },
                confirmButton = {
                    NeonButton(
                        text = "DESAFIAR DUELO",
                        onClick = { selectedUser = null },
                        neonColor = NeonPink,
                        glowColor = NeonPinkGlow
                    )
                },
                dismissButton = {
                    TextButton(onClick = { selectedUser = null }) {
                        Text("CERRAR", color = TextMuted)
                    }
                }
            )
        }
    }
}
