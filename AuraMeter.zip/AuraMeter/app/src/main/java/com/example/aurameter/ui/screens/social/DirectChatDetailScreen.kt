package com.example.aurameter.ui.screens.social

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.CardGiftcard
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.aurameter.data.ChatMessage
import com.example.aurameter.data.MockRepository
import com.example.aurameter.ui.components.NeonButton
import com.example.aurameter.ui.theme.*

@Composable
fun DirectChatDetailScreen(
    contactId: String,
    navController: NavController
) {
    val contact = MockRepository.contacts.find { it.id == contactId } ?: MockRepository.contacts.first()
    val messages = MockRepository.chatMessages
    var inputMessage by remember { mutableStateOf("") }
    var showGiftModal by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            // CONTACT HEADER WITH PHOTO, AURA, RANK & ACTIVE MISSION
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .shadow(12.dp, ambientColor = NeonCyanGlow),
                color = AuraDarkSurface
            ) {
                Column(
                    modifier = Modifier.padding(16.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            IconButton(onClick = { navController.popBackStack() }) {
                                Icon(Icons.Filled.ArrowBack, contentDescription = "Back", tint = TextPrimary)
                            }

                            // Contact Avatar
                            Box(
                                modifier = Modifier
                                    .size(48.dp)
                                    .clip(CircleShape)
                                    .background(
                                        brush = Brush.linearGradient(listOf(NeonPurple, NeonPink))
                                    )
                                    .border(1.5.dp, NeonCyan, CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(contact.name.take(1), color = TextPrimary, fontWeight = FontWeight.Black, fontSize = 20.sp)
                            }

                            Column {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Text(contact.name, color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                                    Surface(
                                        color = NeonGold.copy(alpha = 0.2f),
                                        shape = RoundedCornerShape(6.dp)
                                    ) {
                                        Text("#${contact.rank}", color = NeonGold, fontSize = 10.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
                                    }
                                }
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Icon(Icons.Filled.Bolt, contentDescription = null, tint = NeonCyan, modifier = Modifier.size(14.dp))
                                    Text("${contact.auraPoints} AURA", color = NeonCyan, fontSize = 12.sp, fontWeight = FontWeight.Black)
                                }
                            }
                        }

                        // PROMINENT GIFT AURA BUTTON
                        NeonButton(
                            text = "REGALAR AURA",
                            onClick = { showGiftModal = true },
                            neonColor = NeonGold,
                            glowColor = NeonGoldGlow,
                            leadingIcon = { Icon(Icons.Filled.CardGiftcard, contentDescription = null, tint = AuraDarkBackground, modifier = Modifier.size(16.dp)) }
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // ACTIVE MISSION BADGE
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        color = AuraGlassOverlay,
                        shape = RoundedCornerShape(10.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, NeonPurple.copy(alpha = 0.4f))
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text("Misión en curso:", color = TextMuted, fontSize = 11.sp)
                            Text(contact.activeMission, color = NeonPink, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        },
        bottomBar = {
            // INPUT MESSAGE BAR
            Surface(
                modifier = Modifier.fillMaxWidth(),
                color = AuraDarkSurface
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    TextField(
                        value = inputMessage,
                        onValueChange = { inputMessage = it },
                        placeholder = { Text("Escribe un mensaje de Aura...", color = TextMuted) },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(20.dp),
                        colors = TextFieldDefaults.colors(
                            focusedContainerColor = AuraCardSurface,
                            unfocusedContainerColor = AuraCardSurface,
                            focusedIndicatorColor = NeonCyan,
                            unfocusedIndicatorColor = Color.Transparent,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary
                        )
                    )

                    IconButton(
                        onClick = {
                            if (inputMessage.isNotBlank()) {
                                messages.add(
                                    ChatMessage(
                                        id = "msg_${System.currentTimeMillis()}",
                                        senderId = "user_me",
                                        senderName = "Kaelen Voss",
                                        text = inputMessage,
                                        timestamp = "Ahora",
                                        isFromMe = true
                                    )
                                )
                                inputMessage = ""
                            }
                        },
                        modifier = Modifier
                            .size(48.dp)
                            .clip(CircleShape)
                            .background(
                                brush = Brush.linearGradient(listOf(NeonCyan, NeonPurple))
                            )
                    ) {
                        Icon(Icons.Filled.Send, contentDescription = "Send", tint = AuraDarkBackground)
                    }
                }
            }
        },
        containerColor = AuraDarkBackground
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            contentPadding = PaddingValues(vertical = 16.dp)
        ) {
            items(messages, key = { it.id }) { msg ->
                ChatMessageBubble(message = msg)
            }
        }
    }

    // GIFT AURA MODAL DIALOG
    if (showGiftModal) {
        AlertDialog(
            onDismissRequest = { showGiftModal = false },
            containerColor = AuraDarkSurface,
            title = {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(Icons.Filled.CardGiftcard, contentDescription = null, tint = NeonGold)
                    Text("Regalar Aura a ${contact.name}", color = TextPrimary, fontWeight = FontWeight.Black)
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(
                        "Selecciona la cantidad de Aura que deseas transferir de tu reserva actual (${MockRepository.currentUser.value.auraPoints} AURA):",
                        color = TextSecondary,
                        fontSize = 12.sp
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        GiftAmountOption(500) {
                            MockRepository.giftAura(contact.id, 500)
                            showGiftModal = false
                        }
                        GiftAmountOption(1000) {
                            MockRepository.giftAura(contact.id, 1000)
                            showGiftModal = false
                        }
                        GiftAmountOption(5000) {
                            MockRepository.giftAura(contact.id, 5000)
                            showGiftModal = false
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showGiftModal = false }) {
                    Text("CANCELAR", color = TextMuted)
                }
            }
        )
    }
}

@Composable
private fun GiftAmountOption(amount: Int, onClick: () -> Unit) {
    Surface(
        modifier = Modifier
            .clip(RoundedCornerShape(12.dp))
            .background(NeonGold.copy(alpha = 0.2f))
            .border(1.dp, NeonGold, RoundedCornerShape(12.dp)),
        color = Color.Transparent,
        onClick = onClick
    ) {
        Text(
            text = "+$amount",
            color = NeonGold,
            fontSize = 13.sp,
            fontWeight = FontWeight.Black,
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
        )
    }
}

@Composable
private fun ChatMessageBubble(message: ChatMessage) {
    if (message.isSystemNotice) {
        Box(
            modifier = Modifier.fillMaxWidth(),
            contentAlignment = Alignment.Center
        ) {
            Surface(
                color = NeonGold.copy(alpha = 0.15f),
                shape = RoundedCornerShape(16.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, NeonGold)
            ) {
                Text(
                    text = message.text,
                    color = NeonGold,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
                )
            }
        }
    } else {
        val alignment = if (message.isFromMe) Alignment.CenterEnd else Alignment.CenterStart
        val bgColor = if (message.isFromMe) NeonPurple.copy(alpha = 0.3f) else AuraCardSurface

        Box(
            modifier = Modifier.fillMaxWidth(),
            contentAlignment = alignment
        ) {
            Surface(
                color = bgColor,
                shape = RoundedCornerShape(18.dp),
                border = androidx.compose.foundation.BorderStroke(
                    1.dp,
                    if (message.isFromMe) NeonCyan else NeonPurple.copy(alpha = 0.5f)
                )
            ) {
                Column(
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp)
                ) {
                    Text(
                        text = message.text,
                        color = TextPrimary,
                        fontSize = 14.sp
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = message.timestamp,
                        color = TextMuted,
                        fontSize = 10.sp
                    )
                }
            }
        }
    }
}
