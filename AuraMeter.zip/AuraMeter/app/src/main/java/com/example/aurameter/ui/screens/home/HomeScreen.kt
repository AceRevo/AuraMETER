package com.example.aurameter.ui.screens.home

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.aurameter.data.DailyChallenge
import com.example.aurameter.data.MockRepository
import com.example.aurameter.ui.components.AuraGlowCard
import com.example.aurameter.ui.components.NeonButton
import com.example.aurameter.ui.navigation.AuraTopBar
import com.example.aurameter.ui.navigation.Screen
import com.example.aurameter.ui.theme.*

@Composable
fun HomeScreen(navController: NavController) {
    val currentUser by MockRepository.currentUser
    val challenges = MockRepository.dailyChallenges

    var rewardNotification by remember { mutableStateOf<String?>(null) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(AuraDarkBackground)
    ) {
        Column(
            modifier = Modifier.fillMaxSize()
        ) {
            // TOP BAR
            AuraTopBar(
                user = currentUser,
                onProfileClick = { navController.navigate(Screen.Settings.route) },
                onAuraClick = { navController.navigate(Screen.Leaderboard.route) }
            )

            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // SUB-HEADER: GLOBAL RANKING STATUS CARD
                item {
                    GlobalRankHeaderCard(
                        userRank = currentUser.globalRank,
                        streakDays = currentUser.streakDays,
                        multiplier = currentUser.auraMultiplier,
                        clanName = currentUser.clanName ?: "Sin Clan",
                        onLeaderboardClick = { navController.navigate(Screen.Leaderboard.route) }
                    )
                }

                // QUICK ACCESS FEATURE SHORTCUTS
                item {
                    Text(
                        text = "ECOSISTEMA AURA",
                        color = TextPrimary,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Black,
                        letterSpacing = 1.2.sp,
                        modifier = Modifier.padding(vertical = 4.dp)
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        FeatureShortcutCard(
                            title = "Mapa Heatmap",
                            subtitle = "Zonas de Calor",
                            icon = Icons.Filled.Map,
                            gradient = listOf(NeonCyan, NeonPurple),
                            modifier = Modifier.weight(1f),
                            onClick = { navController.navigate(Screen.AuraMap.route) }
                        )
                        FeatureShortcutCard(
                            title = "Ruleta Diaria",
                            subtitle = "3 Tiros Gratis",
                            icon = Icons.Filled.Casino,
                            gradient = listOf(NeonPink, NeonGold),
                            modifier = Modifier.weight(1f),
                            onClick = { navController.navigate(Screen.DailyRoulette.route) }
                        )
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        FeatureShortcutCard(
                            title = "Clanes",
                            subtitle = "Aura Colectiva",
                            icon = Icons.Filled.Shield,
                            gradient = listOf(NeonEmerald, NeonCyan),
                            modifier = Modifier.weight(1f),
                            onClick = { navController.navigate(Screen.ClanSystem.route) }
                        )
                        FeatureShortcutCard(
                            title = "Ranking Top",
                            subtitle = "Tabla Semanal",
                            icon = Icons.Filled.EmojiEvents,
                            gradient = listOf(NeonGold, NeonPurple),
                            modifier = Modifier.weight(1f),
                            onClick = { navController.navigate(Screen.Leaderboard.route) }
                        )
                    }
                }

                // DAILY CHALLENGES CONTAINER
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "RETOS DIARIOS DE AURA",
                            color = TextPrimary,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Black,
                            letterSpacing = 1.2.sp
                        )
                        Surface(
                            color = NeonPurple.copy(alpha = 0.2f),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text(
                                text = "${challenges.count { it.isCompleted }}/${challenges.size} COMPLETADOS",
                                color = NeonPurple,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }
                }

                // CHALLENGES LIST
                items(challenges, key = { it.id }) { challenge ->
                    DailyChallengeCard(
                        challenge = challenge,
                        onComplete = {
                            MockRepository.completeChallenge(challenge.id)
                            rewardNotification = "¡RECOMPENSA! +${challenge.rewardAura} AURA (${challenge.rewardMultiplier})"
                        }
                    )
                }
            }
        }

        // ANIMATED REWARD TOAST / POPUP
        AnimatedVisibility(
            visible = rewardNotification != null,
            enter = slideInVertically(initialOffsetY = { -it }) + fadeIn(),
            exit = slideOutVertically(targetOffsetY = { -it }) + fadeOut(),
            modifier = Modifier
                .align(Alignment.TopCenter)
                .padding(top = 70.dp)
        ) {
            Surface(
                modifier = Modifier
                    .shadow(16.dp, RoundedCornerShape(20.dp), spotColor = NeonGold)
                    .clip(RoundedCornerShape(20.dp))
                    .background(
                        brush = Brush.horizontalGradient(listOf(NeonGold, NeonPink))
                    )
                    .clickable { rewardNotification = null }
                    .padding(horizontal = 20.dp, vertical = 12.dp),
                color = Color.Transparent
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(Icons.Filled.Bolt, contentDescription = null, tint = AuraDarkBackground)
                    Text(
                        text = rewardNotification ?: "",
                        color = AuraDarkBackground,
                        fontWeight = FontWeight.Black,
                        fontSize = 14.sp
                    )
                }
            }
        }
    }
}

@Composable
private fun GlobalRankHeaderCard(
    userRank: Int,
    streakDays: Int,
    multiplier: Float,
    clanName: String,
    onLeaderboardClick: () -> Unit
) {
    AuraGlowCard(
        borderColor = NeonGold,
        glowColor = NeonGoldGlow
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "POSICIÓN GLOBAL",
                    color = TextSecondary,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )
                Text(
                    text = "#$userRank LÍDER MUNDIAL",
                    color = NeonGold,
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Black
                )
                Text(
                    text = "Clan: $clanName",
                    color = TextMuted,
                    fontSize = 12.sp
                )
            }

            Box(
                modifier = Modifier
                    .size(54.dp)
                    .shadow(8.dp, CircleShape, spotColor = NeonGold)
                    .clip(CircleShape)
                    .background(NeonGold.copy(alpha = 0.15f))
                    .border(2.dp, NeonGold, CircleShape)
                    .clickable(onClick = onLeaderboardClick),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Filled.EmojiEvents,
                    contentDescription = "Leaderboard",
                    tint = NeonGold,
                    modifier = Modifier.size(28.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Aura Multiplier & Streak Progress Bar
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                Icon(Icons.Filled.LocalFireDepartment, contentDescription = null, tint = NeonPink, modifier = Modifier.size(16.dp))
                Text(text = "Racha: $streakDays días", color = TextPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
            Text(text = "Multiplicador: x$multiplier", color = NeonCyan, fontSize = 12.sp, fontWeight = FontWeight.ExtraBold)
        }

        Spacer(modifier = Modifier.height(6.dp))

        LinearProgressIndicator(
            progress = { 0.78f },
            modifier = Modifier
                .fillMaxWidth()
                .height(8.dp)
                .clip(RoundedCornerShape(4.dp)),
            color = NeonCyan,
            trackColor = AuraDarkSurface
        )
    }
}

@Composable
private fun FeatureShortcutCard(
    title: String,
    subtitle: String,
    icon: ImageVector,
    gradient: List<Color>,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Box(
        modifier = modifier
            .shadow(8.dp, RoundedCornerShape(16.dp), spotColor = gradient.first().copy(alpha = 0.4f))
            .clip(RoundedCornerShape(16.dp))
            .background(
                brush = Brush.verticalGradient(
                    colors = listOf(AuraCardSurface, AuraDarkSurface)
                )
            )
            .border(
                width = 1.dp,
                brush = Brush.horizontalGradient(gradient),
                shape = RoundedCornerShape(16.dp)
            )
            .clickable(onClick = onClick)
            .padding(12.dp)
    ) {
        Column {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(gradient.first().copy(alpha = 0.2f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(imageVector = icon, contentDescription = title, tint = gradient.first(), modifier = Modifier.size(20.dp))
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text(text = title, color = TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Bold)
            Text(text = subtitle, color = TextSecondary, fontSize = 10.sp)
        }
    }
}

@Composable
private fun DailyChallengeCard(
    challenge: DailyChallenge,
    onComplete: () -> Unit
) {
    AuraGlowCard(
        borderColor = if (challenge.isCompleted) NeonEmerald else NeonPurple,
        glowColor = if (challenge.isCompleted) NeonEmeraldGlow else NeonPurpleGlow
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                modifier = Modifier.weight(1f),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .clip(CircleShape)
                        .background(
                            if (challenge.isCompleted) NeonEmerald.copy(alpha = 0.2f) else NeonPurple.copy(alpha = 0.2f)
                        )
                        .border(
                            1.dp,
                            if (challenge.isCompleted) NeonEmerald else NeonPurple,
                            CircleShape
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = if (challenge.isCompleted) Icons.Filled.CheckCircle else Icons.Filled.Bolt,
                        contentDescription = null,
                        tint = if (challenge.isCompleted) NeonEmerald else NeonCyan
                    )
                }

                Column {
                    Text(
                        text = challenge.title,
                        color = TextPrimary,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = challenge.description,
                        color = TextSecondary,
                        fontSize = 11.sp,
                        maxLines = 2
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "+${challenge.rewardAura} AURA",
                            color = NeonCyan,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Black
                        )
                        Surface(
                            color = NeonPink.copy(alpha = 0.15f),
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Text(
                                text = challenge.rewardMultiplier,
                                color = NeonPink,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.width(8.dp))

            if (challenge.isCompleted) {
                Surface(
                    color = NeonEmerald.copy(alpha = 0.15f),
                    shape = RoundedCornerShape(12.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, NeonEmerald)
                ) {
                    Text(
                        text = "LISTO ✓",
                        color = NeonEmerald,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.ExtraBold,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
                    )
                }
            } else {
                NeonButton(
                    text = "COMPLETAR",
                    onClick = onComplete,
                    neonColor = NeonCyan,
                    glowColor = NeonCyanGlow
                )
            }
        }
    }
}
