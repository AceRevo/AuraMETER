package com.example.aurameter.ui.screens.leaderboard

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.MilitaryTech
import androidx.compose.material.icons.filled.WorkspacePremium
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.aurameter.data.LeaderboardUser
import com.example.aurameter.data.MockRepository
import com.example.aurameter.ui.components.AuraGlowCard
import com.example.aurameter.ui.components.AuraProgressRing
import com.example.aurameter.ui.theme.*

@Composable
fun WeeklyLeaderboardScreen(navController: NavController) {
    val leaderboard = MockRepository.weeklyLeaderboard
    val leader = leaderboard.firstOrNull { it.isLeader } ?: leaderboard.first()
    val otherUsers = leaderboard.filter { !it.isLeader }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(AuraDarkBackground)
    ) {
        Column(
            modifier = Modifier.fillMaxSize()
        ) {
            // TOP HEADER BAR
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = { navController.popBackStack() },
                    modifier = Modifier
                        .clip(CircleShape)
                        .background(AuraDarkSurface)
                ) {
                    Icon(Icons.Filled.ArrowBack, contentDescription = "Back", tint = TextPrimary)
                }

                Text(
                    text = "RANKING SEMANAL DE AURA",
                    color = TextPrimary,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Black,
                    letterSpacing = 1.2.sp
                )

                Spacer(modifier = Modifier.width(48.dp))
            }

            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // MASSIVE HIGHLIGHT FOR WEEKLY LEADER (#1)
                item {
                    WeeklyLeaderCrownCard(leader = leader)
                }

                // STATS OVERVIEW CHART & MOMENTUM RING
                item {
                    WeeklyStatsOverviewCard()
                }

                item {
                    Text(
                        text = "TABLA DE CLASIFICACIÓN GLOBAL",
                        color = TextPrimary,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Black,
                        letterSpacing = 1.sp
                    )
                }

                // DESCENDING RANKINGS LIST
                items(otherUsers, key = { it.id }) { user ->
                    LeaderboardUserCard(user = user)
                }
            }
        }
    }
}

@Composable
private fun WeeklyLeaderCrownCard(leader: LeaderboardUser) {
    AuraGlowCard(
        borderColor = NeonGold,
        glowColor = NeonGoldGlow
    ) {
        Column(
            modifier = Modifier.fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // CROWN ICON ABOVE AVATAR
            Icon(
                imageVector = Icons.Filled.WorkspacePremium,
                contentDescription = "Crown",
                tint = NeonGold,
                modifier = Modifier.size(36.dp)
            )

            Spacer(modifier = Modifier.height(6.dp))

            // BIG GLOWING AVATAR WITH NEON AURA RING
            Box(
                modifier = Modifier
                    .size(90.dp)
                    .shadow(16.dp, CircleShape, spotColor = NeonGold)
                    .clip(CircleShape)
                    .background(
                        brush = Brush.radialGradient(
                            colors = listOf(NeonGold, NeonPink, AuraDarkSurface)
                        )
                    )
                    .border(3.dp, NeonGold, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = leader.name.take(1),
                    color = TextPrimary,
                    fontSize = 36.sp,
                    fontWeight = FontWeight.Black
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // LEADER NAME & TITLE
            Text(
                text = leader.name,
                color = TextPrimary,
                fontSize = 20.sp,
                fontWeight = FontWeight.Black
            )

            Surface(
                color = NeonGold.copy(alpha = 0.2f),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text(
                    text = leader.badgeTitle.uppercase(),
                    color = NeonGold,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.ExtraBold,
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // POINTS DISPLAY
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Icon(Icons.Filled.Bolt, contentDescription = null, tint = NeonCyan, modifier = Modifier.size(22.dp))
                Text(
                    text = "${leader.totalAura} AURA",
                    color = NeonCyan,
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Black
                )
            }

            Text(
                text = "+${leader.weeklyGain} Aura Ganada Esta Semana",
                color = NeonEmerald,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

@Composable
private fun WeeklyStatsOverviewCard() {
    AuraGlowCard(
        borderColor = NeonPurple,
        glowColor = NeonPurpleGlow
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text("MOMENTUM DE LA RED", color = TextSecondary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Text("98.4% Actividad", color = NeonCyan, fontSize = 18.sp, fontWeight = FontWeight.Black)
                Spacer(modifier = Modifier.height(6.dp))
                Text("Se han generado +1.2M de Aura colectiva en los últimos 7 días.", color = TextMuted, fontSize = 12.sp)
            }

            AuraProgressRing(
                progress = 0.85f,
                modifier = Modifier.size(70.dp),
                strokeWidth = 8.dp,
                primaryColor = NeonCyan,
                secondaryColor = NeonPink
            ) {
                Text("TOP 5%", color = NeonGold, fontSize = 11.sp, fontWeight = FontWeight.Black)
            }
        }
    }
}

@Composable
private fun LeaderboardUserCard(user: LeaderboardUser) {
    val rankColor = when (user.rank) {
        2 -> Color(0xFFC0C0C0) // Silver
        3 -> Color(0xFFCD7F32) // Bronze
        else -> NeonPurple
    }

    AuraGlowCard(
        borderColor = rankColor,
        glowColor = rankColor.copy(alpha = 0.4f)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Rank Number Pill
                Surface(
                    color = rankColor.copy(alpha = 0.2f),
                    shape = RoundedCornerShape(10.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, rankColor)
                ) {
                    Text(
                        text = "#${user.rank}",
                        color = if (user.rank <= 3) rankColor else TextPrimary,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Black,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp)
                    )
                }

                // Avatar
                Box(
                    modifier = Modifier
                        .size(42.dp)
                        .clip(CircleShape)
                        .background(
                            brush = Brush.linearGradient(listOf(NeonPurple, NeonPink))
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Text(user.name.take(1), color = TextPrimary, fontWeight = FontWeight.Black)
                }

                Column {
                    Text(user.name, color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Text(user.badgeTitle, color = TextMuted, fontSize = 11.sp)
                }
            }

            Column(horizontalAlignment = Alignment.End) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Icon(Icons.Filled.Bolt, contentDescription = null, tint = NeonCyan, modifier = Modifier.size(14.dp))
                    Text("${user.totalAura}", color = NeonCyan, fontSize = 14.sp, fontWeight = FontWeight.Black)
                }
                Text("+${user.weeklyGain} esta semana", color = NeonEmerald, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}
