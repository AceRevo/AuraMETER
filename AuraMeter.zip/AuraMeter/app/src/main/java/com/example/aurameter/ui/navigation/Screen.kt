package com.example.aurameter.ui.navigation

sealed class Screen(val route: String, val title: String) {
    // Bottom Bar Tabs
    object Home : Screen("home", "Inicio")
    object Social : Screen("social", "Social")
    object Settings : Screen("settings", "Ajustes")

    // Ecosystem Sub-screens
    object AuraMap : Screen("aura_map", "Mapa de Aura")
    object DailyRoulette : Screen("daily_roulette", "Ruleta Diaria")
    object ClanSystem : Screen("clan_system", "Sistema de Clanes")
    object Leaderboard : Screen("leaderboard", "Ranking Semanal")
    object DirectChatDetail : Screen("chat_detail/{contactId}", "Chat Directo") {
        fun createRoute(contactId: String) = "chat_detail/$contactId"
    }
    object Auth : Screen("auth", "Autenticación")
}
